package com.example.crud.form;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FormRepository extends JpaRepository<Form, Long> {
    // เราจะใช้เมธอดที่มีมาใน JpaRepository เช่น save(), findAll() เป็นต้น
}
