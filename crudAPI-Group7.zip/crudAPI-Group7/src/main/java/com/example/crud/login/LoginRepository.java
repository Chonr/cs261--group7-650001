// StudentRepository.java
package com.example.crud.login;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LoginRepository extends JpaRepository<Login, Long> {
    // Custom query method
    Login findByUserName(String userName);
}
