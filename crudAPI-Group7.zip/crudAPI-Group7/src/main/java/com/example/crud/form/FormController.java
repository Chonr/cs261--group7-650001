package com.example.crud.form;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/form_data")
@CrossOrigin(origins = "http://localhost:3000")
public class FormController {

	@Autowired
    private FormRepository formRepository;

    // API สำหรับรับข้อมูลฟอร์มและบันทึกลงฐานข้อมูล
	@PostMapping
	public ResponseEntity<String> saveForm(@RequestBody Form form) {
	    try {
	        formRepository.save(form); // บันทึกข้อมูลไปยังฐานข้อมูล
	        return ResponseEntity.ok("Form data saved successfully!");
	    } catch (Exception e) {
	        return ResponseEntity.status(500).body("Error saving form data: " + e.getMessage());
	    }
	}

    
}


